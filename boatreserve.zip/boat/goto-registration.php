<a href="register.php">
	Register
	<span class="glyphicon glyphicon-user" aria-hidden="true"></span>
</a>