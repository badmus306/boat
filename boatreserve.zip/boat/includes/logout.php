<a href="../logout.php">
	Logout
	<span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>
</a>